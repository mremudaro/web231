let btnSubmit = document.getElementById("btnSubmit");
let result = document.getElementById("result");

const rnd = Math.floor((Math.random()*10)+1); //creates random number

btnSubmit.addEventListener('click', function(){    //on click event to begin game
    var myNumber = parseInt(document.getElementById("txtMyNumber").value);
    
    if(rnd == myNumber) // if else branches to check guess
    {    
        result.innerHTML = "Congratulations! You guessed Correctly";
    }
    else if(rnd > myNumber)
    {    
        result.innerHTML = "The number is greater than " + myNumber;
    }
    else if(rnd < myNumber)
    {
        result.innerHTML = "The number is less than " + myNumber;
    }    
});